
import numpy as np
from courses import Courses
from student import Student
from course import Course

class Advisory(object):
    
    def __init__(self, student : Student):
        self.courses = Courses()
        self.st = student

        self.courses.initiateCourses()
        self.courses.getAllYears()
        
        self.courList = self.courses.getAllcourses()
        self.yearOneC = self.courses.yearOneCour
        self.yearTwoeC = self.courses.yearTwoCour
        self.yearThreeC = self.courses.yearThreeCour
        self.achievement = int
        self.advise = False
        self.examCommittee = "Contact the exam Committee"
    
                   
    def Fourth_course(self):
        for wish in self.st.wishedCourses:
            if self.courList[wish].getOrientation() == self.st.getOrientation():
                if self.st.motivation > 7 :
                    self.advise = True
                    
    def above_four_course(self):
        for wish in self.st.wishedCourses:
            if self.courList[wish].getOrientation() == self.st.getOrientation():
                if self.st.motivation > 9 :
                    self.advise = True


    
